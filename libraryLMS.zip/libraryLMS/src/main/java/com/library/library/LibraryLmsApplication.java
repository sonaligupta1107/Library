package com.library.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryLmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryLmsApplication.class, args);
	}

}
