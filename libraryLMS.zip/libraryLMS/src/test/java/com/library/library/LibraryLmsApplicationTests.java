package com.library.library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryLmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
